const db = require("../routes/db");

exports.create = async (req, res) => {
  const { text, description } = req.body;

  try {
    const query = "INSERT INTO task SET ?";

    db.query(query, { text, description }, (error, rows, field) => {
      if (error) {
        return res.status(400).json({ message: "Failed", error });
      }

      res.status(201).json(rows);
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

exports.findAll = async (req, res) => {
  try {
    const query = "SELECT * FROM task";

    db.query(query, (error, rows, field) => {
      if (error) {
        return res.status(400).json({ message: error });
      }

      return res.status(200).json(rows);
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

exports.update = async (req, res) => {
  const { id } = req.params;

  try {
    const data = { ...req.body };
    const querySearch = "SELECT * FROM task WHERE id = ?";
    const queryUpdate = "UPDATE task SET ? WHERE id = ?";

    db.query(querySearch, id, (error, rows, field) => {
      if (error) {
        return res.status(500).json({ message: "Ada kesalahan", error });
      }

      if (rows.length) {
        db.query(queryUpdate, [data, id], (error, rows, field) => {
          if (error) {
            return res.status(500).json({ message: "Ada kesalahan", error });
          }

          res
            .status(200)
            .json({ success: true, message: "Berhasil update data!" });
        });
      } else {
        return res
          .status(404)
          .json({ message: "Data tidak ditemukan!", success: false });
      }
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

exports.remove = async (req, res) => {
  const { id } = req.params;

  try {
    const querySearch = "SELECT * FROM task WHERE id = ?";
    const queryDelete = "DELETE FROM task WHERE id = ?";

    db.query(querySearch, id, (error, rows, field) => {
      if (error) {
        return res.status(500).json({ message: "Ada kesalahan", error });
      }
      if (rows.length) {
        db.query(queryDelete, id, (error, rows, field) => {
          if (error) {
            return res.status(500).json({ message: "Ada kesalahan", error });
          }

          res
            .status(200)
            .json({ success: true, message: "Berhasil hapus data!" });
        });
      } else {
        return res
          .status(404)
          .json({ message: "Data tidak ditemukan!", success: false });
      }
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};
