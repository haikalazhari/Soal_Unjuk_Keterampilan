const router = require("express").Router();
const { create, findAll, update, remove } = require("../controllers/tasks");

router.get("/", findAll);
router.post("/", create);
router.put("/:id", update);
router.delete("/:id", remove);

module.exports = router;
