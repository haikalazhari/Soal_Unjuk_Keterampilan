require("dotenv").config();
const express = require("express");
const db = require("./src/routes/db");
const tasksRouter = require("./src/routes/tasks");
const port = process.env.PORT;

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api/tasks", tasksRouter);

app.listen(port, () => console.log(`Server is running at localhost:${port}`));

db.connect((error) => {
  if (error) throw err;
  console.log("MySQL Connected...");
});
